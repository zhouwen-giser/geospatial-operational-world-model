# Complete development server deployment

This package starts the complete GOWM+ development platform, including the
project-owned CRS and Geometry upstreams and both Provider Bridges. It is a
development topology for a trusted LAN or VPN, not a public-internet topology.

## Requirements

- Linux x86-64
- Docker Engine 24 or newer with Docker Compose v2
- 4 CPU, 8 GiB RAM and 20 GiB free disk minimum; 8 CPU and 16 GiB RAM recommended
- outbound access to the configured container registry and npm registry
- Node.js 22 (used by configuration validation); npm and Git are needed only
  when rebuilding the H3 binding outside the release archive

The scripts do not install Docker and do not change the host firewall. Restrict
all published ports to trusted source networks before starting the stack.

## One-command start

```bash
tar -xzf gowm-dev-server-0.7.1.tar.gz
cd gowm-dev-server-0.7.1
./scripts/dev-deploy.sh up
```

The first run creates `.env` with mode `0600`, generates independent random
credentials, verifies the H3 artifact, builds the CRS/Geometry upstream images,
records the deployed `proj.db` and offline-grid attestations, renders Compose,
runs migrations, starts all required services, and waits for health checks.
Re-running the command retains credentials and data.

Useful commands:

```bash
./scripts/dev-deploy.sh doctor
./scripts/dev-deploy.sh status
./scripts/dev-deploy.sh logs world-capability-gateway
./scripts/dev-deploy.sh smoke
./scripts/dev-deploy.sh down
```

`down` intentionally retains named volumes. No deploy command deletes the
database or MQTT data.

## Published endpoints

All host ports and the bind address can be changed in `.env`.

| Service | Default port | Authentication boundary |
|---|---:|---|
| PostgreSQL | 5432 | generated PostgreSQL password |
| MQTT | 1883 | anonymous development broker |
| World API | 3000 | trusted-network only |
| MCP | 3001 | trusted-network only; Gateway calls carry the generated token |
| Observation API | 3002 | trusted-network only |
| STAS | 8080 | trusted-network only |
| World Capability Gateway | 8090 | `GATEWAY_AUTH_SHARED_TOKEN` for protected operations |
| CRS upstream / Geometry upstream | 18080 / 18081 | trusted-network only |
| CRS / Geometry Bridges | 18086 / 18087 | corresponding Provider transport token |
| H3 interactive / analysis | 18088 / 18089 | corresponding Provider transport token |
| Reference / Dataset Providers | 18090 / 18091 | corresponding Provider transport token |
| Situation / Evidence Providers | 18092 / 18093 | corresponding Provider transport token |
| Operational / Validation Providers | 18094 / 18095 | corresponding Provider transport token |
| Network / Route Providers | 18096 / 18097 | corresponding Provider transport token |
| Coverage / STAS Providers | 18098 / 18099 | corresponding Provider transport token |
| Historical / Spatial Providers | 18100 / 18101 | corresponding Provider transport token |

Read a secret only on the deployment host, for example:

```bash
gateway_token="$(awk -F= '$1=="GATEWAY_AUTH_SHARED_TOKEN"{print $2}' .env)"
curl -H "Authorization: Bearer ${gateway_token}" http://127.0.0.1:8090/v1/operation-availability
```

Do not paste `.env`, tokens, passwords, delegated keys, or authenticated request
headers into logs or support tickets.

## Configuration and upgrades

`.env.example` is the canonical catalog for deployment variables. Each group
documents units and defaults; generated passwords and tokens must remain
distinct. Validate changes before restart:

```bash
npm run validate:deployment-env
./scripts/dev-deploy.sh doctor
```

For an established 086+ installation, unpack the new package separately and
retain the approved private environment, project, volumes and dependencies.
Use `functional-repair-upgrade.js --check` / apply for 086→089, then
`capability-completion-upgrade.js --check` / `--projection-workers-stopped`
for 089→093. Recreate only affected GOWM services; do not use whole-project
`up` for a hot update. See [the current retained upgrade procedure](CAPABILITY_COMPLETION_2026_10.md).
Migrations are forward-only; take and test a backup before upgrading retained data.

Rebuilding the deployment archive with `npm run package:dev-deployment`
requires a Git checkout. It packages only tracked files, including the verified
H3 artifact, and excludes local worktrees, generated output, and private
environment files at every depth. Tracked `.env*.example` templates are retained.
Stage any new source files before packaging so they appear in the inventory.

### Reproducible package command

```bash
npm run package:dev-deployment -- --force --verify-image
```

Run this from the repository root. It validates environment templates, packages
the tracked runtime inventory, normalizes non-root read permissions (including
the generated `SHA256SUMS`), checks exclusions and extracted checksums, validates
shell entrypoints, and compares a deterministic repack byte for byte. With
`--verify-image`, it also builds the extracted Docker context and checks migration
readability as the image's non-root user without starting services or using a
database. Docker access and dependency-download connectivity are required for
this option; omit it for archive-only validation.

Outputs are `output/deployment/gowm-dev-server-<version>.tar.gz` and `.tar.gz.sha256`.
Set `GOWM_DEPLOYMENT_OUTPUT_DIR` to select another directory. Existing outputs are
refused unless `--force` is given; replacement preserves the old archive and
companion in a unique `previous-*` directory and occurs only after gates pass.
The command does not commit, push, publish, or deploy. Dependency audit warnings
are not remediated automatically. For a formal release, run from the reviewed
clean commit; a build with tracked local edits is a local candidate, not a clean
commit release. Reproducibility means the same source bytes and executable modes
produce identical archive bytes; image dependency downloads are a separate gate.

Image verification also compares every runtime COPY source file against SHA-256
computed from the verified host context, and compares the actual compiled
Operational Provider manifest with its image-declared manifest. Build success
alone is insufficient. To check an already built image independently, run
`node scripts/verify-deployment-image.mjs <image> <verified-extracted-package>`.
Any mismatch blocks publication; do not bypass registry identity checks. A
`docker build --no-cache` retry is not sufficient: a real counterexample retained
stale source bytes even without layer reuse. The package command streams the full
verified context (`tar -C <context> -cf - . | docker build --tag <image> -`) to avoid
directory-delta source reuse. Use this path for normalized release archives and
run the independent image check before deployment. The Dockerfile additionally
refuses an Operational manifest/runtime mismatch.

Reusable archive-only helper (Node with built-in modules, Docker and tar; no host
`node_modules` required):

```bash
bash scripts/build-verified-image.sh <image-tag> <verified-package-directory>
```

It validates `SHA256SUMS`, streams only that inventory (not a generated `.env` or
runtime directories), builds the normal Dockerfile, and verifies image bytes and
runtime identity. It does not start containers other than an offline read-only
verification process, migrate databases, tag remote releases or deploy services.
Outer Compose coordinators should assign this verified image to GOWM runtime
services and use `up --no-build`; do not follow this with an ordinary directory
build that can replace it with stale COPY content. Other upstream images use
their own independently verified build contexts.

## Security boundary

The development override binds all ports to `0.0.0.0`. MQTT remains anonymous,
and Foundation APIs do not gain a new authentication layer. Use host or network
firewall rules to allow only the trusted LAN/VPN CIDRs. Do not expose this
topology directly to the public internet.

### Shared device business storage

The deployment includes migrations through 093, hosted native SQL, scope
overlays and the v2 controlled business API. New installations automatically
install native schemas before managed accounts. For an explicit admin install use
`node dist/scripts/business-storage/cli.js install --domain all` (with an
explicit `GOWM_DATABASE_URL`) and `node dist/scripts/business-storage/cli.js verify`.
`verify --domain smpp|sdar` checks a selected installed domain. `--help` needs no
database. The database image supplies pinned pgvector 0.8.6; only the fresh
initializer creates the extension. Packaging does not contact a database or
switch consumers.

The ordinary storage fixture/test harness remains excluded from the deployment
archive. Run those commands from the source checkout against an isolated test
DB. The runtime CLI loads that optional harness only for fixture/test commands,
so excluding tests does not prevent production compilation.

### UGV actor device prerequisite

New MQTT sessions use mapper v3 by default, or v4 with an explicitly registered
and activated runtime profile. Both require device initialization before startup.
Apply migration 079, run the production `device-cli.js init-default` and
`verify-default` commands, and grant the ingest login `gowm_device_reader`.
See [UGV device actor deployment](UGV_DEVICE_ACTOR.md) for the complete environment,
service binding contract, read-only verification, and persistent-session cutover.
The default initializer creates configuration only; it does not create test observations.
Source clock calibration, physical origin/CRS opt-in and controlled session
cutover are described in [the capability guide](CAPABILITY_COMPLETION_2026_10.md).
Optional authenticated HTTPS/MQTT and logical recovery are described in
[the operations guide](PRODUCTION_OPERATIONS.md); the dev overlay does not enable them.

### 默认设备及业务数据库账号

新包执行 `scripts/dev-deploy.sh init` 后，设置实际 `UGV_MQTT_URL`，再执行 `up`。
默认启用 UGV 采集，并自带来源锁定的协议文件。正式迁移完成后自动创建两个业务数据库
正式原生表和两个账号，再登记设备主档/端点/7 条流、服务绑定及登录授权，
执行主档检查及两个实际业务账号的只读检查，成功后自动订阅设备 MQTT。
既有 .env、范围、来源和世界对象会复用；初始化冲突会阻止采集启动。

数据库账号固定为 `ugv_smpp_app` / `ugv_sdar_app`，随机密码及连接配置在安装目录的
`.runtime/dev-deploy/business-connections.env`（0600），不写入分发包或日志。
重复安装不旋转密码。默认 `storage` 模式安装正式 native 表；`ingest` 显式跳过，
`ready` 要求完整服务绑定。缺服务配置为 `NOT_CONFIGURED`，不代表业务就绪。
详见 [本轮安装、权限及升级合同](FUNCTIONAL_REPAIR_2026_10.md)。
